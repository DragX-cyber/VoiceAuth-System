// src/pages/Settings.jsx
import React from 'react';

export default function Settings() {
  return (
    <div>
      <h1>Settings Page</h1>
      <p>(Configuration options, user profile, etc., will go here)</p>
    </div>
  );
}