import React, { useState, useEffect } from 'react';
import {
    LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
    Tooltip, Legend, ResponsiveContainer, AreaChart, Area, RadarChart,
    PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import './Analytics.css';

function Analytics() {
    const [authResult, setAuthResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [userId, setUserId] = useState('');
    const [recording, setRecording] = useState(false);
    const [audioBlob, setAudioBlob] = useState(null);

    const startRecording = async () => {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        const chunks = [];

        mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
        mediaRecorder.onstop = () => {
            const blob = new Blob(chunks, { type: 'audio/wav' });
            setAudioBlob(blob);
        };

        mediaRecorder.start();
        setRecording(true);

        setTimeout(() => {
            mediaRecorder.stop();
            setRecording(false);
            stream.getTracks().forEach(track => track.stop());
        }, 3000);
    };

    const handleAuthenticate = async () => {
        if (!audioBlob || !userId) return;

        setLoading(true);
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('audio_file', audioBlob, 'auth.wav');

        try {
            const response = await fetch('http://localhost:5001/api/authenticate', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            setAuthResult(data);
        } catch (error) {
            console.error('Authentication error:', error);
        } finally {
            setLoading(false);
        }
    };

    // Prepare chart data
    const prepareFrameScoresData = () => {
        if (!authResult?.analytics) return [];
        
        const { llr_per_frame, user_scores, ubm_scores } = authResult.analytics;
        
        return llr_per_frame.map((llr, i) => ({
            frame: i,
            'User Score': user_scores[i],
            'UBM Score': ubm_scores[i],
            'LLR': llr
        }));
    };

    const prepareWaveformData = () => {
        if (!authResult?.analytics?.waveform) return [];
        
        const { amplitude, time } = authResult.analytics.waveform;
        
        return amplitude.map((amp, i) => ({
            time: time[i].toFixed(3),
            amplitude: amp
        }));
    };

    const prepareMFCCComparisonData = () => {
        if (!authResult?.analytics?.feature_comparison) return [];
        
        const { mfcc_labels, test_mfcc, enrolled_mfcc, differences } = 
            authResult.analytics.feature_comparison;
        
        return mfcc_labels.map((label, i) => ({
            coefficient: label,
            'Test Audio': test_mfcc[i],
            'Enrolled Voice': enrolled_mfcc[i],
            'Difference': differences[i]
        }));
    };

    const prepareRadarData = () => {
        if (!authResult?.analytics?.feature_comparison) return [];
        
        const { mfcc_labels, test_mfcc, enrolled_mfcc } = 
            authResult.analytics.feature_comparison;
        
        return mfcc_labels.slice(0, 8).map((label, i) => ({
            subject: label,
            Test: Math.abs(test_mfcc[i]),
            Enrolled: Math.abs(enrolled_mfcc[i]),
            fullMark: 3
        }));
    };

    return (
        <div className="analytics-container">
            <h1>🎤 Voice Authentication Analytics</h1>

            {/* Authentication Controls */}
            <div className="auth-controls">
                <input
                    type="text"
                    placeholder="Enter User ID"
                    value={userId}
                    onChange={(e) => setUserId(e.target.value)}
                    className="user-id-input"
                />
                
                <button
                    onClick={startRecording}
                    disabled={recording}
                    className="btn-record"
                >
                    {recording ? '⏺ Recording...' : '🎤 Record Voice'}
                </button>

                <button
                    onClick={handleAuthenticate}
                    disabled={!audioBlob || !userId || loading}
                    className="btn-authenticate"
                >
                    {loading ? '⏳ Authenticating...' : '🔐 Authenticate'}
                </button>
            </div>

            {/* Results Section */}
            {authResult && (
                <>
                    {/* Status Header */}
                    <div className={`status-header ${authResult.authenticated ? 'success' : 'failed'}`}>
                        <div className="status-icon">
                            {authResult.authenticated ? '✅' : '❌'}
                        </div>
                        <div className="status-details">
                            <h2>{authResult.authenticated ? 'AUTHENTICATED' : 'AUTHENTICATION FAILED'}</h2>
                            <div className="confidence-display">
                                <div className="confidence-label">Confidence Score</div>
                                <div className="confidence-value">{authResult.confidence.toFixed(1)}%</div>
                                <div className="llr-value">LLR: {authResult.llr.toFixed(2)}</div>
                            </div>
                        </div>
                    </div>

                    {/* Analytics Dashboard */}
                    <div className="analytics-dashboard">
                        
                        {/* Waveform */}
                        <div className="chart-container">
                            <h3>📊 Audio Waveform</h3>
                            <ResponsiveContainer width="100%" height={250}>
                                <AreaChart data={prepareWaveformData()}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="time" label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }} />
                                    <YAxis label={{ value: 'Amplitude', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip />
                                    <Area type="monotone" dataKey="amplitude" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>

                        {/* Frame-by-Frame Scores */}
                        <div className="chart-container">
                            <h3>📈 Frame-by-Frame Authentication Scores</h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={prepareFrameScoresData()}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="frame" label={{ value: 'Frame Number', position: 'insideBottom', offset: -5 }} />
                                    <YAxis label={{ value: 'Log-Likelihood', angle: -90, position: 'insideLeft' }} />
                                    <Tooltip />
                                    <Legend />
                                    <Line type="monotone" dataKey="User Score" stroke="#82ca9d" strokeWidth={2} dot={false} />
                                    <Line type="monotone" dataKey="UBM Score" stroke="#8884d8" strokeWidth={2} dot={false} />
                                    <Line type="monotone" dataKey="LLR" stroke="#ff7300" strokeWidth={3} dot={false} />
                                </LineChart>
                            </ResponsiveContainer>
                            <p className="chart-explanation">
                                {authResult.authenticated 
                                    ? '✓ User Score consistently above UBM Score (positive LLR) indicates voice match'
                                    : '✗ User Score below UBM Score (negative LLR) indicates voice mismatch'}
                            </p>
                        </div>

                        {/* MFCC Comparison */}
                        <div className="chart-container">
                            <h3>🎵 MFCC Feature Comparison</h3>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={prepareMFCCComparisonData()}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="coefficient" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="Test Audio" fill="#8884d8" />
                                    <Bar dataKey="Enrolled Voice" fill="#82ca9d" />
                                    <Bar dataKey="Difference" fill="#ff7300" />
                                </BarChart>
                            </ResponsiveContainer>
                            <p className="chart-explanation">
                                {authResult.authenticated
                                    ? '✓ Small differences indicate similar voice characteristics'
                                    : '✗ Large differences indicate different voice characteristics'}
                            </p>
                        </div>

                        {/* Radar Chart */}
                        <div className="chart-container">
                            <h3>🎯 Voice Profile Comparison (Radar)</h3>
                            <ResponsiveContainer width="100%" height={350}>
                                <RadarChart data={prepareRadarData()}>
                                    <PolarGrid />
                                    <PolarAngleAxis dataKey="subject" />
                                    <PolarRadiusAxis angle={90} domain={[0, 'dataMax']} />
                                    <Radar name="Test Audio" dataKey="Test" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                                    <Radar name="Enrolled Voice" dataKey="Enrolled" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                                    <Legend />
                                    <Tooltip />
                                </RadarChart>
                            </ResponsiveContainer>
                            <p className="chart-explanation">
                                {authResult.authenticated
                                    ? '✓ Overlapping profiles show voice similarity'
                                    : '✗ Distinct profiles show different voice characteristics'}
                            </p>
                        </div>

                        {/* Statistics Table */}
                        <div className="stats-container">
                            <h3>📊 Detailed Statistics</h3>
                            <table className="stats-table">
                                <tbody>
                                    <tr>
                                        <td>Audio Duration</td>
                                        <td>{authResult.analytics.audio_duration.toFixed(2)}s</td>
                                    </tr>
                                    <tr>
                                        <td>Feature Frames</td>
                                        <td>{authResult.analytics.num_frames}</td>
                                    </tr>
                                    <tr>
                                        <td>Euclidean Distance</td>
                                        <td>{authResult.analytics.feature_stats.euclidean_distance.toFixed(3)}</td>
                                    </tr>
                                    <tr>
                                        <td>Cosine Similarity</td>
                                        <td>{authResult.analytics.feature_stats.cosine_similarity.toFixed(3)}</td>
                                    </tr>
                                    <tr className="highlight">
                                        <td><strong>Final Confidence</strong></td>
                                        <td><strong>{authResult.confidence.toFixed(1)}%</strong></td>
                                    </tr>
                                    <tr className="highlight">
                                        <td><strong>Decision</strong></td>
                                        <td><strong>{authResult.authenticated ? 'ACCESS GRANTED' : 'ACCESS DENIED'}</strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </>
            )}
        </div>
    );
}

export default Analytics;
