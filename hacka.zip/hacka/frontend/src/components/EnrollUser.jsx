// src/components/EnrollUser.jsx
import React, { useState, useRef } from 'react';

import { enrollUser } from '../services/api';

// Import styles from other components to maintain consistency
import loginStyles from './LoginVoice.module.css';
import cardStyles from './Card.module.css';


const EnrollUser = () => {
  const [userId, setUserId] = useState('');
  const [passphrase, setPassphrase] = useState('Hello, world!'); // Default passphrase
  const [audioBlobs, setAudioBlobs] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState('Idle');
  const [result, setResult] = useState(null);

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  const startRecording = async () => {
    if (audioBlobs.length >= 5) {
      setStatus('You have already recorded the maximum number of samples.');
      return;
    }
    setStatus('Initializing recorder...');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Ensure WAV format is used for recording
      const options = { mimeType: 'audio/wav' };
      if (!MediaRecorder.isTypeSupported(options.mimeType)) {
        console.warn(`Recording in ${options.mimeType} is not supported. Falling back to default browser format.`);
        // If wav is not supported, clear the options to let the browser use its default.
        // The backend is robust enough to handle other formats like webm.
        options.mimeType = ''; 
      }
      
      mediaRecorderRef.current = new MediaRecorder(stream, options);

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = () => {
        // Use the mimeType from the recorder itself to ensure consistency
        const blob = new Blob(audioChunksRef.current, { type: mediaRecorderRef.current.mimeType || 'audio/wav' });
        setAudioBlobs(prevBlobs => [...prevBlobs, blob]);
        audioChunksRef.current = [];
        stream.getTracks().forEach(track => track.stop()); // Stop microphone access
        setStatus(`${audioBlobs.length + 1} sample(s) recorded.`);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      setStatus('Recording for 3 seconds...');

      // Automatically stop recording after 3 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current) {
          mediaRecorderRef.current.stop();
          setIsRecording(false);
        }
      }, 3000);

    } catch (err) {
      console.error('Error starting recording:', err);
      setStatus('Error: Could not access microphone.');
    }
  };

  const handleEnroll = async () => {
    if (audioBlobs.length < 3) {
      setStatus('Please record at least 3 voice samples.');
      return;
    }
    if (!userId) {
      setStatus('Please enter a user ID.');
      return;
    }

    setStatus('Enrolling user...');
    setResult(null);

    try {
      const data = await enrollUser(userId, passphrase, audioBlobs);
      setResult(data);
      setStatus(data.message || 'Enrollment process completed.');
      if (data.success) {
        // Reset form on success
        setAudioBlobs([]);
      }
    } catch (error) {
      console.error('Enrollment failed:', error);
      setStatus(`Enrollment Failed: ${error.response?.data?.detail || error.message || 'Unknown error'}`);
    }
  };

  return (
    <div className={`${cardStyles.card} ${loginStyles.loginCard}`}>
      <h2 className={cardStyles.cardTitle}>New User Enrollment</h2>
      <p className={loginStyles.status}><strong>Status:</strong> {status}</p>

      <div className={loginStyles.inputGroup}>
        <input
          type="text"
          placeholder="Enter User ID"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          className={loginStyles.inputField}
        />
      </div>

      <div className={loginStyles.inputGroup}>
        <input
          type="text"
          placeholder="Enter Passphrase"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          className={loginStyles.inputField}
        />
        <small>You will be prompted to say this phrase.</small>
      </div>

      <div className={loginStyles.buttonGroup}>
        <button 
          onClick={startRecording} 
          disabled={isRecording || audioBlobs.length >= 5}
          className={`${loginStyles.button} ${loginStyles.buttonPrimary}`}
        >
          {isRecording ? 'Recording...' : `Record Sample (${audioBlobs.length}/5)`}
        </button>
        <button 
          onClick={handleEnroll}
          disabled={isRecording || audioBlobs.length < 3}
          className={`${loginStyles.button} ${loginStyles.buttonSecondary}`}
        >
          Enroll User
        </button>
      </div>

      {result && (
        <div className={loginStyles.resultContainer}>
          <h3>Enrollment Result:</h3>
          <p><strong>{result.success ? '✅ Success' : '❌ Failed'}</strong></p>
          <p>Samples Processed: {result.samples_processed}</p>
          {result.error && <p>Error: {result.error}</p>}
          {result.verification_details && (
            <ul>
              {result.verification_details.map((detail) => (
                <li key={detail.sample}>
                  Sample {detail.sample}: {detail.verified ? '✓ Verified' : '✗ Failed'}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default EnrollUser;