// src/components/VoiceLevelMeter.jsx
import React, { useState, useEffect, useRef } from 'react';
import './VoiceLevelMeter.css';

export default function VoiceLevelMeter({ isActive = false }) {
    const [voiceLevel, setVoiceLevel] = useState(0);
    const [frequency, setFrequency] = useState(0);
    const [peakLevel, setPeakLevel] = useState(0);
    const [isSpeaking, setIsSpeaking] = useState(false);
    
    const audioContextRef = useRef(null);
    const analyserRef = useRef(null);
    const microphoneRef = useRef(null);
    const animationFrameRef = useRef(null);
    const streamRef = useRef(null);

    useEffect(() => {
        if (isActive) {
            startMicrophone();
        } else {
            stopMicrophone();
        }

        return () => {
            stopMicrophone();
        };
    }, [isActive]);

    const startMicrophone = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;

            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const analyser = audioContext.createAnalyser();
            const microphone = audioContext.createMediaStreamSource(stream);

            analyser.smoothingTimeConstant = 0.8;
            analyser.fftSize = 2048;
            microphone.connect(analyser);

            audioContextRef.current = audioContext;
            analyserRef.current = analyser;
            microphoneRef.current = microphone;

            analyzeVoice();
        } catch (err) {
            console.error('Microphone access error:', err);
        }
    };

    const stopMicrophone = () => {
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }

        if (audioContextRef.current) {
            audioContextRef.current.close();
        }

        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }

        setVoiceLevel(0);
        setFrequency(0);
        setIsSpeaking(false);
    };

    const analyzeVoice = () => {
        if (!analyserRef.current) return;

        const bufferLength = analyserRef.current.fftSize;
        const dataArray = new Float32Array(bufferLength);
        const frequencyData = new Uint8Array(analyserRef.current.frequencyBinCount);

        analyserRef.current.getFloatTimeDomainData(dataArray);
        analyserRef.current.getByteFrequencyData(frequencyData);

        // Calculate RMS (voice level)
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
            sum += dataArray[i] * dataArray[i];
        }
        const rms = Math.sqrt(sum / bufferLength);
        const level = Math.min(100, rms * 500); // Scale to 0-100

        setVoiceLevel(level);

        // Update peak level
        if (level > peakLevel) {
            setPeakLevel(level);
        }

        // Detect speaking (threshold: 5%)
        setIsSpeaking(level > 5);

        // Calculate dominant frequency
        let maxIndex = 0;
        let maxValue = 0;
        for (let i = 0; i < frequencyData.length; i++) {
            if (frequencyData[i] > maxValue) {
                maxValue = frequencyData[i];
                maxIndex = i;
            }
        }
        const freq = (maxIndex * audioContextRef.current.sampleRate) / analyserRef.current.fftSize;
        setFrequency(Math.round(freq));

        animationFrameRef.current = requestAnimationFrame(analyzeVoice);
    };

    const getLevelColor = (level) => {
        if (level < 20) return '#10b981'; // Green - Low
        if (level < 50) return '#3b82f6'; // Blue - Medium
        if (level < 80) return '#f59e0b'; // Orange - High
        return '#ef4444'; // Red - Very High
    };

    const getLevelLabel = (level) => {
        if (level < 20) return 'Low';
        if (level < 50) return 'Good';
        if (level < 80) return 'Loud';
        return 'Too Loud';
    };

    return (
        <div className="voice-level-meter">
            <div className="meter-header">
                <h3>Voice Level Monitor</h3>
                <div className={`status-indicator ${isSpeaking ? 'speaking' : ''}`}>
                    <span className="status-dot"></span>
                    {isSpeaking ? 'Speaking' : 'Silent'}
                </div>
            </div>

            {/* Main Level Display */}
            <div className="level-display">
                <div className="level-value" style={{ color: getLevelColor(voiceLevel) }}>
                    {voiceLevel.toFixed(1)}%
                </div>
                <div className="level-label">{getLevelLabel(voiceLevel)}</div>
            </div>

            {/* Visual Bar */}
            <div className="level-bar-container">
                <div
                    className="level-bar"
                    style={{
                        width: `${voiceLevel}%`,
                        background: getLevelColor(voiceLevel),
                    }}
                >
                    <div className="level-bar-glow"></div>
                </div>
                
                {/* Peak Marker */}
                {peakLevel > 0 && (
                    <div
                        className="peak-marker"
                        style={{ left: `${peakLevel}%` }}
                    ></div>
                )}
            </div>

            {/* Level Scale */}
            <div className="level-scale">
                <span>0%</span>
                <span>25%</span>
                <span>50%</span>
                <span>75%</span>
                <span>100%</span>
            </div>

            {/* Segments Visualization */}
            <div className="level-segments">
                {Array.from({ length: 20 }).map((_, i) => (
                    <div
                        key={i}
                        className={`segment ${voiceLevel > (i + 1) * 5 ? 'active' : ''}`}
                        style={{
                            background: voiceLevel > (i + 1) * 5 ? getLevelColor((i + 1) * 5) : '#e5e7eb',
                        }}
                    ></div>
                ))}
            </div>

            {/* Additional Stats */}
            <div className="voice-stats">
                <div className="stat-item">
                    <div className="stat-icon">🎵</div>
                    <div className="stat-info">
                        <div className="stat-value">{frequency} Hz</div>
                        <div className="stat-label">Frequency</div>
                    </div>
                </div>

                <div className="stat-item">
                    <div className="stat-icon">📊</div>
                    <div className="stat-info">
                        <div className="stat-value">{peakLevel.toFixed(1)}%</div>
                        <div className="stat-label">Peak Level</div>
                    </div>
                </div>

                <div className="stat-item">
                    <div className="stat-icon">
                        {isSpeaking ? '🎙️' : '🔇'}
                    </div>
                    <div className="stat-info">
                        <div className="stat-value">
                            {isSpeaking ? 'Active' : 'Idle'}
                        </div>
                        <div className="stat-label">Status</div>
                    </div>
                </div>
            </div>

            {!isActive && (
                <div className="meter-inactive">
                    <p>🎤 Click "Start Analysis" to activate voice monitoring</p>
                </div>
            )}
        </div>
    );
}
