import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

function WaveformComparison({ analytics }) {
    if (!analytics?.waveforms) return null;
    
    const { enrollment, verification } = analytics.waveforms;
    
    // Prepare data for chart
    const data = enrollment.amplitude.map((enrollAmp, i) => ({
        time: i / 16000,
        enrollment: enrollAmp,
        verification: verification.amplitude[i] || 0
    }));
    
    return (
        <div className="waveform-comparison">
            <h3>🎵 Waveform Comparison</h3>
            
            <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                        dataKey="time" 
                        label={{ value: 'Time (s)', position: 'insideBottom', offset: -5 }} 
                    />
                    <YAxis label={{ value: 'Amplitude', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Line 
                        type="monotone" 
                        dataKey="enrollment" 
                        stroke="#82ca9d" 
                        name="Enrolled Voice" 
                        dot={false}
                    />
                    <Line 
                        type="monotone" 
                        dataKey="verification" 
                        stroke="#8884d8" 
                        name="Current Voice" 
                        dot={false}
                    />
                </LineChart>
            </ResponsiveContainer>
            
            <div className="waveform-stats">
                <p>
                    {analytics.statistics?.positive_frame_ratio >= 0.6 
                        ? '✓ Waveforms match closely'
                        : '✗ Waveforms differ significantly'}
                </p>
            </div>
        </div>
    );
}

export default WaveformComparison;
