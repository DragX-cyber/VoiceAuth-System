import pickle
import torch

def convert_ubm_to_numpy(input_path='models/ubm.pkl', output_path='models/ubm_portable.pkl'):
    with open(input_path, 'rb') as f:
        ubm_data = pickle.load(f)
    if isinstance(ubm_data, dict):
        portable_data = ubm_data
    else:
        portable_data = {
            'weights': ubm_data.weights_.cpu().numpy(),
            'means': ubm_data.means_.cpu().numpy(),
            'covariances': ubm_data.covariances_.cpu().numpy(),
            'n_components': ubm_data.n_components
        }
    with open(output_path, 'wb') as f:
        pickle.dump(portable_data, f, protocol=4)
    print(f"✓ Saved portable UBM as {output_path}")

if __name__ == '__main__':
    convert_ubm_to_numpy('models/ubm.pkl', 'models/ubm_portable.pkl')
