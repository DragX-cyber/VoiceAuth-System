"""
Diagnostic script to check backend setup.
Run this before starting backend_api.py
"""

import os
import sys

print("="*60)
print("BACKEND DIAGNOSTIC CHECK")
print("="*60)

# Check 1: File structure
print("\n1. Checking file structure...")
required_files = [
    'backend_api.py',
    'ai_service.py',
    'models/ubm.pkl'
]

for file in required_files:
    if os.path.exists(file):
        size = os.path.getsize(file)
        print(f"   ✓ {file} ({size/1024/1024:.2f} MB)")
    else:
        print(f"   ✗ {file} NOT FOUND")

# Check 2: Directories
print("\n2. Checking directories...")
if not os.path.exists('models/users'):
    print("   ⚠️ models/users/ doesn't exist, creating...")
    os.makedirs('models/users', exist_ok=True)
    print("   ✓ Created models/users/")
else:
    print("   ✓ models/users/ exists")

# Check 3: Import ai_service
print("\n3. Testing ai_service import...")
try:
    from ai_service import VoiceAuthenticationService
    print("   ✓ ai_service imports successfully")
except Exception as e:
    print(f"   ✗ Import failed: {e}")
    sys.exit(1)

# Check 4: Initialize AI service
print("\n4. Testing AI service initialization...")
try:
    ai = VoiceAuthenticationService(
        ubm_path='models/ubm.pkl',
        users_dir='models/users'
    )
    print("   ✓ AI service initialized")
    print(f"   ✓ UBM components: {ai.n_components}")
except Exception as e:
    print(f"   ✗ Initialization failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "="*60)
print("✅ ALL CHECKS PASSED")
print("="*60)
print("\nYou can now run: python backend_api.py")
