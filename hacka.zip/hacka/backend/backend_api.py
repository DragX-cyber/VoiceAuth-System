"""
Complete FastAPI Backend
Connects AI Service with Frontend
Handles: Enrollment, Authentication, Alerts, Analytics
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import uvicorn
from io import BytesIO
from datetime import datetime
import json
import os

# Import your AI service
from ai_service import VoiceAuthenticationService

# Initialize FastAPI app
app = FastAPI(
    title="Voice Authentication Backend",
    description="AI-powered voice authentication with enrollment and real-time verification",
    version="1.0.0"
)


try:
    print("\n🔄 Initializing AI Service...")
    print(f"   UBM path: models/ubm.pkl")
    print(f"   Users dir: models/users")
    
    # Check if files exist
    if not os.path.exists('models/ubm.pkl'):
        print("❌ ERROR: models/ubm.pkl NOT FOUND")
        print("   Please copy your trained UBM model to models/ubm.pkl")
        ai_service = None
    else:
        print("✓ UBM file found")
        
        # Create users directory if doesn't exist
        os.makedirs('models/users', exist_ok=True)
        print("✓ Users directory ready")
        
        # Initialize service
        ai_service = VoiceAuthenticationService(
            ubm_path='models/ubm.pkl',
            users_dir='models/users'
        )
        print("✓ AI Service initialized successfully")

except Exception as e:
    print(f"❌ Failed to initialize AI service:")
    print(f"   Error: {e}")
    import traceback
    traceback.print_exc()
    ai_service = None
    
# CORS middleware - Allow frontend to access backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize AI service
try:
    ai_service = VoiceAuthenticationService(
        ubm_path='models/ubm.pkl',
        users_dir='models/users'
    )
    print("✓ AI Service initialized successfully")
except Exception as e:
    print(f"❌ Failed to initialize AI service: {e}")
    ai_service = None

# Store alerts in memory (in production, use a database)
alerts_db = []


@app.get("/")
async def root():
    """Root endpoint - API information."""
    return {
        "service": "Voice Authentication Backend",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "ai_service": "active" if ai_service else "failed"
    }


@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "ok",
        "service": "voice-authentication-backend",
        "version": "1.0.0",
        "ai_service": "active" if ai_service else "inactive",
        "timestamp": datetime.now().isoformat()
    }


# ========== ENROLLMENT ENDPOINT ==========

@app.post("/api/auth/enroll")
async def enroll_user_endpoint(
    user_id: str = Form(...),
    passphrase: str = Form(...),
    files: List[UploadFile] = File(...)
):
    """Enroll user with detailed sample tracking."""
    if not ai_service:
        raise HTTPException(status_code=503, detail="AI service not available")
    
    try:
        print(f"\n📝 Enrollment request for user: {user_id}")
        
        # Validate
        if len(files) < 3:
            raise HTTPException(status_code=400, detail=f"Need at least 3 audio files")
        
        # Track each sample
        sample_details = []
        audio_buffers = []
        
        for i, audio_file in enumerate(files):
            print(f"   Processing sample {i+1}: {audio_file.filename}")
            
            content = await audio_file.read()
            buffer = BytesIO(content)
            buffer.name = audio_file.filename
            
            # Basic validation
            audio_size_kb = len(content) / 1024
            
            sample_details.append({
                "sample_number": i + 1,
                "filename": audio_file.filename,
                "size_kb": round(audio_size_kb, 2),
                "status": "processing"
            })
            
            audio_buffers.append(buffer)
        
        # Enroll user
        result = ai_service.enroll_user(user_id, passphrase, audio_buffers)
        
        if result['success']:
            # Mark successful samples
            num_verified = result.get('samples_verified', len(files))
            for i in range(num_verified):
                sample_details[i]["status"] = "✓ accepted"
            
            for i in range(num_verified, len(files)):
                sample_details[i]["status"] = "✗ rejected"
            
            return {
                "success": True,
                "user_id": user_id,
                "message": "User enrolled successfully",
                "samples_processed": len(files),
                "samples_accepted": num_verified,
                "samples_rejected": len(files) - num_verified,
                "sample_details": sample_details,  # ← Show which samples were accepted
                "total_frames": result.get('total_frames', 0),
                "timestamp": datetime.now().isoformat()
            }
        else:
            raise HTTPException(status_code=400, detail=result.get('error'))
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Enrollment error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))



# ========== AUTHENTICATION/VERIFY ENDPOINT ==========

@app.post("/api/auth/verify")
async def verify_user_endpoint(
    user_id: str = Form(...),
    file: UploadFile = File(...)
):
    """
    Verify/authenticate a user with voice sample.
    
    Expected from frontend:
    - user_id: string
    - file: single audio file
    
    Returns: { authenticated, confidence, user_id, ... }
    """
    if not ai_service:
        raise HTTPException(status_code=503, detail="AI service not available")
    
    try:
        print(f"\n🔐 Verification request for user: {user_id}")
        print(f"   File: {file.filename}")
        
        # Read audio file
        content = await file.read()
        audio_buffer = BytesIO(content)
        audio_buffer.name = file.filename
        
        # Authenticate using AI service
        result = ai_service.authenticate_user(
            user_id=user_id,
            audio_file=audio_buffer,
            return_analytics=True  # Return analytics for frontend visualization
        )
        
        if 'error' in result:
            print(f"❌ Verification failed: {result['error']}")
            return {
                "authenticated": False,
                "user_id": user_id,
                "confidence": 0.0,
                "message": result['error'],
                "timestamp": datetime.now().isoformat()
            }
        
        # Log result
        if result['authenticated']:
            print(f"✅ User {user_id} authenticated (confidence: {result['confidence']:.1f}%)")
        else:
            print(f"❌ User {user_id} rejected (confidence: {result['confidence']:.1f}%)")
        
        return {
            "authenticated": result['authenticated'],
            "user_id": user_id,
            "confidence": result['confidence'],
            "llr": result.get('llr', 0),
            "analytics": result.get('analytics', {}),
            "timestamp": datetime.now().isoformat()
        }
    
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Verification error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# ========== ALERTS ENDPOINT ==========

@app.post("/api/alerts")
async def log_alert(
    user_id: str = Form(...),
    alert_type: str = Form(...),
    message: Optional[str] = Form(None)
):
    """
    Log security alert.
    
    Expected from frontend:
    - user_id: string
    - alert_type: string (e.g., 'failed_auth', 'spoofing_detected')
    - message: optional string
    
    Returns: { success, alert_id }
    """
    try:
        alert = {
            "alert_id": len(alerts_db) + 1,
            "user_id": user_id,
            "alert_type": alert_type,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        
        alerts_db.append(alert)
        
        print(f"⚠️ Alert logged: {alert_type} for user {user_id}")
        
        return {
            "success": True,
            "alert_id": alert["alert_id"],
            "message": "Alert logged successfully"
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/alerts")
async def get_alerts(user_id: Optional[str] = None):
    """Get all alerts or alerts for specific user."""
    if user_id:
        user_alerts = [a for a in alerts_db if a['user_id'] == user_id]
        return {"alerts": user_alerts, "count": len(user_alerts)}
    else:
        return {"alerts": alerts_db, "count": len(alerts_db)}


# ========== USER MANAGEMENT ==========

@app.get("/api/users")
async def list_users():
    """List all enrolled users."""
    if not ai_service:
        raise HTTPException(status_code=503, detail="AI service not available")
    
    try:
        users_dir = ai_service.users_dir
        users = []
        
        if os.path.exists(users_dir):
            for filename in os.listdir(users_dir):
                if filename.endswith('.pkl'):
                    user_id = filename[:-4]
                    users.append({
                        "user_id": user_id,
                        "enrolled": True
                    })
        
        return {
            "success": True,
            "users": users,
            "total": len(users)
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/users/{user_id}")
async def delete_user(user_id: str):
    """Delete an enrolled user."""
    if not ai_service:
        raise HTTPException(status_code=503, detail="AI service not available")
    
    try:
        user_path = os.path.join(ai_service.users_dir, f'{user_id}.pkl')
        
        if not os.path.exists(user_path):
            raise HTTPException(status_code=404, detail=f"User {user_id} not found")
        
        os.remove(user_path)
        
        print(f"🗑️ User {user_id} deleted")
        
        return {
            "success": True,
            "message": f"User {user_id} deleted successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ========== STATISTICS ==========

@app.get("/api/stats")
async def get_stats():
    """Get system statistics."""
    try:
        users_count = 0
        if ai_service and os.path.exists(ai_service.users_dir):
            users_count = len([f for f in os.listdir(ai_service.users_dir) if f.endswith('.pkl')])
        
        return {
            "total_users": users_count,
            "total_alerts": len(alerts_db),
            "ai_service_status": "active" if ai_service else "inactive",
            "uptime": "running"
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == '__main__':
    print("="*60)
    print("🚀 VOICE AUTHENTICATION BACKEND API")
    print("="*60)
    print("\n📡 Endpoints:")
    print("  POST   /api/auth/enroll       - Enroll new user")
    print("  POST   /api/auth/verify       - Verify/authenticate user")
    print("  POST   /api/alerts            - Log security alert")
    print("  GET    /api/alerts            - Get all alerts")
    print("  GET    /api/users             - List enrolled users")
    print("  DELETE /api/users/<user_id>   - Delete user")
    print("  GET    /api/stats             - System statistics")
    print("  GET    /api/health            - Health check")
    print("\n🌐 Server: http://localhost:8000")
    print("📚 API Docs: http://localhost:8000/docs")
    print("="*60 + "\n")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
