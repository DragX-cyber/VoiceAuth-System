"""
Voice Authentication AI Service
Complete unified service for backend integration
Handles: Enrollment, Authentication, User Management
"""

import os
import pickle
import numpy as np
import torch
import librosa
import soundfile as sf
from io import BytesIO
import hashlib
from datetime import datetime
from pydub import AudioSegment
from random import randint


class VoiceAuthenticationService:
    """
    Complete voice authentication service.
    Handles all AI operations for backend integration.
    """

    def _load_audio(self, audio_file):
        """Load audio from webm/ogg/wav using FFmpeg via pydub if needed."""
        from io import BytesIO
        import numpy as np
        import soundfile as sf
        from pydub import AudioSegment
        import librosa
        import os
        os.environ["TORCH_USE_RTLD_GLOBAL"] = "0"
        os.environ["TORCHAUDIO_DISABLE_LIBTORCHCODEC"] = "1"
        os.environ["TORCHAUDIO_USE_BACKEND"] = "false"
        try:
            # Convert uploaded file to byte buffer
            if hasattr(audio_file, "read"):
                audio_file.seek(0)
                buffer = BytesIO(audio_file.read())
            elif isinstance(audio_file, str):
                with open(audio_file, "rb") as f:
                    buffer = BytesIO(f.read())
            else:
                print("[ERROR] Unsupported input type:", type(audio_file))
                return None

            # --- Try with SoundFile first (supports WAV/FLAC) ---
            try:
                audio, sr = sf.read(buffer)
                print(f"[INFO] Loaded audio via soundfile at sr={sr}")
            except Exception as e:
                # --- Fall back to Pydub (FFmpeg required for webm/ogg) ---
                print(f"[DEBUG] SoundFile failed, using FFmpeg: {e}")
                buffer.seek(0)

                try:
                    audio_segment = AudioSegment.from_file(buffer)
                    samples = audio_segment.get_array_of_samples()
                    sr = audio_segment.frame_rate
                    audio = np.array(samples).astype(np.float32) / (2 ** 15)

                    # Convert multi-channel -> mono
                    if audio_segment.channels > 1:
                        audio = audio.reshape((-1, audio_segment.channels)).mean(axis=1)

                    print(f"[INFO] Loaded audio using FFmpeg backend, sr={sr}")
                except Exception as e2:
                    print("[FATAL] Cannot decode via ffmpeg:", e2)
                    raise RuntimeError(
                        "Failed to read uploaded audio file (FFmpeg not detected)."
                    )

            # --- Resample to 16kHz ---
            if sr != 16000:
                audio = librosa.resample(audio, orig_sr=sr, target_sr=16000)

            # --- Normalize audio ---
            audio = audio / (np.max(np.abs(audio)) + 1e-8)

            return audio

        except Exception as e:
            print(f"[ERROR] Failed to load audio: {e}")
            return None


    def __init__(self, ubm_path='models/ubm.pkl', users_dir='models/users'):
        """Initialize the service with model and user directory."""
        self.ubm_path = ubm_path
        self.users_dir = users_dir

        self._load_ubm()
        os.makedirs(users_dir, exist_ok=True)

        print("âœ“ Voice Authentication Service initialized")
        print(f"  UBM: {ubm_path}")
        print(f"  Users: {users_dir}")


    def _load_ubm(self):
        """Load Universal Background Model."""
        try:
            with open(self.ubm_path, 'rb') as f:
                ubm_data = pickle.load(f)

            if isinstance(ubm_data, dict):
                self.ubm_weights = torch.from_numpy(ubm_data['weights']).float()
                self.ubm_means = torch.from_numpy(ubm_data['means']).float()
                self.ubm_covariances = torch.from_numpy(ubm_data['covariances']).float()
                self.n_components = ubm_data['n_components']
            else:
                self.ubm_weights = ubm_data.weights_.cpu()
                self.ubm_means = ubm_data.means_.cpu()
                self.ubm_covariances = ubm_data.covariances_.cpu()
                self.n_components = ubm_data.n_components

            print(f"âœ“ UBM loaded: {self.n_components} components")

        except Exception as e:
            raise RuntimeError(f"Failed to load UBM: {e}")


    # ========== ENROLLMENT ==========
    def enroll_user(self, user_id, passphrase, audio_files):
        try:
            audio_samples = []
            for audio_file in audio_files:
                audio = self._load_audio(audio_file)
                if audio is not None:
                    audio_samples.append(audio)

            if len(audio_samples) < 3:
                return {
                    'success': False,
                    'user_id': user_id,
                    'error': f'Need at least 3 valid samples, got {len(audio_samples)}'
                }

            all_features = []
            for audio in audio_samples:
                features = self._extract_features(audio)
                if features is not None:
                    all_features.append(features)

            if len(all_features) < 3:
                return {
                    'success': False,
                    'user_id': user_id,
                    'error': 'Feature extraction failed for most samples'
                }

            user_features = np.vstack(all_features).astype(np.float32)
            user_model, adapted_count = self._adapt_ubm_to_user(user_features)

            user_data = {
                'user_id': user_id,
                'passphrase_hash': hashlib.sha256(passphrase.encode()).hexdigest(),
                'weights': user_model['weights'].cpu().numpy(),
                'means': user_model['means'].cpu().numpy(),
                'covariances': user_model['covariances'].cpu().numpy(),
                'n_components': self.n_components,
                'num_samples': len(audio_samples),
                'total_frames': user_features.shape[0],
                'adapted_components': adapted_count,
                'enrolled_at': datetime.now().isoformat()
            }

            user_path = os.path.join(self.users_dir, f'{user_id}.pkl')
            with open(user_path, 'wb') as f:
                pickle.dump(user_data, f)

            return {
                'success': True,
                'user_id': user_id,
                'samples_verified': len(audio_samples),
                'total_frames': int(user_features.shape[0]),
                'adapted_components': int(adapted_count),
                'message': 'User enrolled successfully',
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            return {'success': False, 'user_id': user_id, 'error': str(e)}


    # ========== AUTHENTICATION ==========
    def authenticate_user(self, user_id, audio_file, return_analytics=False):
        try:
            user_data = self._load_user(user_id)
            if user_data is None:
                return {'authenticated': False, 'error': f'User {user_id} not enrolled'}

            audio = self._load_audio(audio_file)
            if audio is None:
                return {'authenticated': False, 'error': 'Failed to load audio'}

            features = self._extract_features(audio)
            if features is None:
                return {'authenticated': False, 'error': 'Feature extraction failed'}

            X = torch.from_numpy(features).float()
            user_weights = torch.from_numpy(user_data['weights']).float()
            user_means = torch.from_numpy(user_data['means']).float()
            user_covariances = torch.from_numpy(user_data['covariances']).float()

            ubm_scores = self._compute_frame_scores(X, self.ubm_weights, self.ubm_means, self.ubm_covariances)
            user_scores = self._compute_frame_scores(X, user_weights, user_means, user_covariances)

            llr_per_frame = user_scores - ubm_scores
            overall_llr = llr_per_frame.mean().item()
            confidence = self._llr_to_confidence(overall_llr)
            authenticated = confidence >= 70.0

            result = {
                'authenticated': bool(authenticated),
                'user_id': user_id,
                'confidence': float(confidence),
                'llr': float(overall_llr),
                'timestamp': datetime.now().isoformat()
            }

            if return_analytics:
                result['analytics'] = {
                    'llr_per_frame': [float(x) for x in llr_per_frame.tolist()],
                    'confidence_curve': [float(x) for x in confidence * np.ones_like(llr_per_frame)]
                }

            return result

        except Exception as e:
            return {'authenticated': False, 'user_id': user_id, 'error': str(e)}


    # ========== FEATURE & MODEL UTILS ==========
    def _extract_features(self, audio, sample_rate=16000):
        try:
            audio = librosa.effects.preemphasis(audio)
            mfccs = librosa.feature.mfcc(
                y=audio, sr=sample_rate, n_fft=512, hop_length=160,
                n_mels=40, n_mfcc=13, fmin=125, fmax=7500
            )
            delta = librosa.feature.delta(mfccs, order=1)
            delta2 = librosa.feature.delta(mfccs, order=2)
            features = np.vstack([mfccs, delta, delta2])
            features -= np.mean(features, axis=1, keepdims=True)
            std = np.std(features, axis=1, keepdims=True)
            std[std < 1e-10] = 1.0
            features /= std
            return features.T
        except Exception as e:
            print(f"Feature extraction error: {e}")
            return None


    def _adapt_ubm_to_user(self, user_features, tau=5):
        X = torch.from_numpy(user_features).float()
        weights = self.ubm_weights.cpu()
        means = self.ubm_means.cpu()
        covariances = self.ubm_covariances.cpu()
        log_prob = -0.5 * (
            torch.log(2 * np.pi * covariances).sum(dim=1) +
            ((X.unsqueeze(1) - means) ** 2 / covariances).sum(dim=2)
        )
        log_weighted_prob = log_prob + torch.log(weights)
        log_resp = log_weighted_prob - torch.logsumexp(log_weighted_prob, dim=1, keepdim=True)
        resp = torch.exp(log_resp)
        n_k = resp.sum(dim=0)
        adapted_means = means.clone()
        adapted_count = 0
        for k in range(self.n_components):
            if n_k[k] > 1.0:
                user_mean_k = (resp[:, k].unsqueeze(1) * X).sum(dim=0) / n_k[k]
                alpha_k = n_k[k] / (n_k[k] + tau)
                adapted_means[k] = alpha_k * user_mean_k + (1 - alpha_k) * means[k]
                adapted_count += 1
        return {
            'weights': weights,
            'means': adapted_means,
            'covariances': covariances
        }, adapted_count


    def _compute_frame_scores(self, X, weights, means, covariances):
        log_prob = -0.5 * (
            torch.log(2 * np.pi * covariances).sum(dim=1) +
            ((X.unsqueeze(1) - means) ** 2 / covariances).sum(dim=2)
        )
        log_weighted = log_prob + torch.log(weights)
        scores = torch.logsumexp(log_weighted, dim=1)
        return scores


    def _llr_to_confidence(self, llr):
        llr = np.clip(llr, -80, 80)
        confidence = 100 / (1 + np.exp(-0.35 * (llr - 5)))
        return confidence


    def _load_user(self, user_id):
        user_path = os.path.join(self.users_dir, f'{user_id}.pkl')
        if not os.path.exists(user_path):
            return None
        try:
            with open(user_path, 'rb') as f:
                return pickle.load(f)
        except:
            return None


# ===== CONVENIENCE FUNCTION =====
def create_service(ubm_path='models/ubm.pkl', users_dir='models/users'):
    return VoiceAuthenticationService(ubm_path, users_dir)


if __name__ == '__main__':
    print("="*60)
    print("VOICE AUTHENTICATION SERVICE - TEST")
    print("="*60)

    service = create_service()
    users = service.list_users() if hasattr(service, 'list_users') else []
    print(f"\nEnrolled users: {len(users)}")
    for user in users:
        print(f"  - {user['user_id']}: {user.get('samples', 0)} samples")

    print("\nâœ“ Service ready for backend integration")